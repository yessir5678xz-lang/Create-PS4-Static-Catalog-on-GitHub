#!/usr/bin/env python3
"""Build a SSPI embedded-catalog-v1 .gssource from local JSON source data.

Only packages/links that the operator owns or is authorized to distribute should be listed.
"""
from __future__ import annotations
import argparse, hashlib, json, re, zipfile
from pathlib import Path
from urllib.parse import urlparse

ENGINE = "embedded-catalog-v1"
NORMALIZATION = "nfkd-lower-alnum-spaces-v1"
TITLE_RE = re.compile(r"^(?!PPSA)[A-Z]{4}[0-9]{5}$")
SHA_RE = re.compile(r"^[0-9a-fA-F]{64}$")
MAX_TITLES_PER_INDEX = 500
MAX_PACKAGES_PER_TITLE = 512
MAX_TITLES = 30000
MAX_BYTES = 4 * 1024 * 1024
MAX_FILES = 64


def fail(msg):
    raise SystemExit(f"ERROR: {msg}")


def canonical_bytes(obj):
    return (json.dumps(obj, ensure_ascii=False, indent=2, sort_keys=True) + "\n").encode("utf-8")


def sha(data):
    return hashlib.sha256(data).hexdigest()


def valid_http_url(value, required=True):
    if not value and not required:
        return
    if not isinstance(value, str):
        fail("URL fields must be strings")
    u = urlparse(value)
    if u.scheme not in ("http", "https") or not u.hostname or u.username or u.password:
        fail(f"URL must be HTTP(S), include a host and contain no embedded credentials: {value!r}")


def check_text(value, label, max_len, required=False):
    if not isinstance(value, str) or len(value) > max_len or (required and not value.strip()):
        fail(f"{label} must be a {'non-empty ' if required else ''}string up to {max_len} characters")
    if any(ord(c) < 32 for c in value):
        fail(f"{label} contains a control character")


def build(data_path: Path, out_path: Path):
    raw = json.loads(data_path.read_text(encoding="utf-8"))
    if not isinstance(raw, dict): fail("input must be a JSON object")
    meta = raw.get("source", {})
    for key in ("id", "name", "version"):
        check_text(meta.get(key), f"source.{key}", 96 if key == "name" else 128, True)
    if not re.fullmatch(r"[A-Za-z0-9._-]+", meta["id"]): fail("source.id may use letters, digits, dot, underscore and hyphen only")
    if not re.fullmatch(r"[A-Za-z0-9.+-]+", meta["version"]): fail("source.version contains unsupported characters")
    if len(meta["version"].split('.')) < 2 or len(meta["version"].split('.')) > 4 or not all(x.isdigit() for x in meta["version"].split('.')):
        fail("static source version must have 2-4 numeric components, e.g. 1.0")

    titles = raw.get("titles")
    if not isinstance(titles, list) or not titles or len(titles) > MAX_TITLES:
        fail(f"titles must be a non-empty array with at most {MAX_TITLES} titles")

    # Static engine's index and package shard files.
    package_shard = {"titles": {}}
    index_rows = []
    total_releases = 0
    kinds_all = set()
    seen_ids = set()

    for title in titles:
        if not isinstance(title, dict): fail("each title must be an object")
        tid = title.get("titleId", "").upper()
        if not TITLE_RE.fullmatch(tid): fail(f"unsupported PS4 titleId {tid!r}; expected e.g. CUSA12345")
        if tid in seen_ids: fail(f"duplicate titleId {tid}")
        seen_ids.add(tid)
        name = title.get("name")
        check_text(name, f"{tid}.name", 512, True)
        region = title.get("region", "")
        check_text(region, f"{tid}.region", 32)
        if region.upper() in ("USA", "EUR", "JPN"): region = {"USA":"US", "EUR":"EU", "JPN":"JP"}[region.upper()]
        icon = title.get("icon", "")
        valid_http_url(icon, required=False)
        search_text = title.get("searchText", "")
        check_text(search_text, f"{tid}.searchText", 2048)

        packages = title.get("packages")
        if not isinstance(packages, list) or not packages or len(packages) > MAX_PACKAGES_PER_TITLE:
            fail(f"{tid}.packages must contain 1-{MAX_PACKAGES_PER_TITLE} entries")
        index_kinds = set()
        package_rows = []
        ids = set()
        for pkg in packages:
            if not isinstance(pkg, dict): fail(f"each package of {tid} must be an object")
            pid = pkg.get("id")
            check_text(pid, f"{tid}.package.id", 256, True)
            if pid in ids: fail(f"duplicate package id {pid!r} for {tid}")
            ids.add(pid)
            kind = pkg.get("kind")
            if kind not in ("base", "update", "dlc", "unknown", "backport"):
                fail(f"{tid}/{pid}: kind must be base, update, dlc, unknown or backport")
            kinds_all.add(kind); index_kinds.add(kind)
            url = pkg.get("url")
            valid_http_url(url, required=True)
            access = pkg.get("accessType")
            if access not in ("Direct", "HosterLanding"):
                fail(f"{tid}/{pid}: accessType must be Direct or HosterLanding")
            row = {"id":pid, "kind":kind, "url":url, "accessType":access}
            optional_text = {
                "label":512, "hoster":256, "version":64, "requiredFirmware":64,
                "groupId":256, "sourcePageUrl":2048, "contentId":128,
                "name":512, "region":32
            }
            for field, limit in optional_text.items():
                if field in pkg:
                    check_text(pkg[field], f"{tid}/{pid}.{field}", limit)
                    if pkg[field] != "": row[field] = pkg[field]
            for field in ("sourcePageUrl",):
                if field in row: valid_http_url(row[field], required=False)
            if "size" in pkg:
                if not isinstance(pkg["size"], int) or pkg["size"] < 0: fail(f"{tid}/{pid}.size must be a non-negative integer")
                if pkg["size"]: row["size"] = pkg["size"]
            for field in ("sha256",):
                if field in pkg:
                    if pkg[field] and not SHA_RE.fullmatch(pkg[field]): fail(f"{tid}/{pid}.{field} must be a 64-digit SHA-256")
                    if pkg[field]: row[field] = pkg[field].lower()
            if "archivePassword" in pkg:
                check_text(pkg["archivePassword"], f"{tid}/{pid}.archivePassword", 256)
                if pkg["archivePassword"]: row["archivePassword"] = pkg["archivePassword"]
            if "archivePasswords" in pkg:
                if not isinstance(pkg["archivePasswords"], list) or len(pkg["archivePasswords"]) > 16: fail("archivePasswords must be an array of at most 16 strings")
                for x in pkg["archivePasswords"]: check_text(x, "archivePasswords[]", 256)
                row["archivePasswords"] = pkg["archivePasswords"]
            if "volumes" in pkg:
                vols = pkg["volumes"]
                if not isinstance(vols, list) or len(vols) < 2 or len(vols) > 128: fail(f"{tid}/{pid}.volumes must contain 2-128 ordered volumes")
                vr = []
                for vol in vols:
                    if not isinstance(vol, dict): fail("each volume must be an object")
                    valid_http_url(vol.get("url"), True)
                    check_text(vol.get("name"), "volume.name", 240, True)
                    if vol.get("accessType") not in ("Direct", "HosterLanding"): fail("volume.accessType must be Direct or HosterLanding")
                    v = {"url":vol["url"], "name":vol["name"], "accessType":vol["accessType"]}
                    if "size" in vol:
                        if not isinstance(vol["size"], int) or vol["size"] < 0: fail("volume.size must be non-negative")
                        if vol["size"]: v["size"] = vol["size"]
                    if vol.get("sha256"):
                        if not SHA_RE.fullmatch(vol["sha256"]): fail("volume.sha256 must be SHA-256")
                        v["sha256"] = vol["sha256"].lower()
                    vr.append(v)
                if row["url"] != vr[0]["url"] or row["accessType"] != vr[0]["accessType"]:
                    fail(f"{tid}/{pid}: multipart parent url/accessType must match the first volume")
                row["volumes"] = vr
            package_rows.append(row)

        # SSPI's index is keyed by titleId (not one entry per package region).
        package_shard["titles"][tid] = package_rows
        index_row = {
            "titleId":tid, "name":name, "region":region, "packagesFile":"packages/0001.json",
            "releaseCount":len(package_rows), "kinds":sorted(index_kinds)
        }
        if icon: index_row["icon"] = icon
        if search_text: index_row["searchText"] = search_text
        index_rows.append(index_row)
        total_releases += len(package_rows)

    # Keep a single title record per titleId. Region is resolved at package level
    # in the SSPI candidate list; if input includes one title per region, merge it.
    merged_index = {}
    for row in index_rows:
        tid = row["titleId"]
        if tid in merged_index:
            prev = merged_index[tid]
            if prev["name"] != row["name"] or prev["packagesFile"] != row["packagesFile"]:
                fail(f"conflicting duplicate index record for {tid}")
            prev["releaseCount"] += row["releaseCount"]
            prev["kinds"] = sorted(set(prev["kinds"]) | set(row["kinds"]))
            if row.get("searchText"):
                prev["searchText"] = (prev.get("searchText", "") + " " + row["searchText"]).strip()
            if not prev.get("region"):
                prev["region"] = row.get("region", "")
        else:
            merged_index[tid] = row
    index_rows = list(merged_index.values())
    payload_files = {
        "index/0001.json": canonical_bytes({"titles":index_rows}),
        "packages/0001.json": canonical_bytes(package_shard),
    }
    catalog = {
        "format":ENGINE, "formatVersion":1, "searchNormalization":NORMALIZATION,
        "indexFiles":["index/0001.json"], "packageFiles":["packages/0001.json"],
        "counts":{"titles":len(titles), "readyTitles":len(titles), "releases":total_releases,
                  "multipartGroups":sum(1 for t in titles for p in t["packages"] if "volumes" in p),
                  "unresolved":0}
    }
    payload_files["catalog.json"] = canonical_bytes(catalog)
    file_declarations = []
    for path, data in sorted(payload_files.items()):
        file_declarations.append({"path":path,"size":len(data),"sha256":sha(data)})
    manifest = {
        "schema":"gamesearch.source/v1", "id":meta["id"], "name":meta["name"],
        "description":meta.get("description", "Personal static catalog"), "version":meta["version"],
        "engine":{"type":ENGINE,"entryFile":"catalog.json"},
        "capabilities":["titles.search","titles.catalog","packages.resolve"],
        "files":file_declarations,
        "homepage":meta.get("homepage", ""), "support":meta.get("support", "")
    }
    for k in ("homepage","support"):
        if manifest[k]: valid_http_url(manifest[k], True)
        else: manifest.pop(k)
    manifest_bytes=canonical_bytes(manifest)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(out_path,"w",compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        z.writestr("source.json",manifest_bytes)
        for path,data in payload_files.items(): z.writestr(path,data)
    size=out_path.stat().st_size
    if size > MAX_BYTES: out_path.unlink(missing_ok=True); fail(f"output compressed size {size} exceeds conservative 4 MiB target")
    with zipfile.ZipFile(out_path) as z:
        if len(z.namelist()) > MAX_FILES: fail("archive entry count exceeds SSPI limit")
        if sum(i.file_size for i in z.infolist()) > 64*1024*1024: fail("expanded archive exceeds SSPI limit")
        bad=z.testzip()
        if bad: fail(f"ZIP CRC failure in {bad}")
    print(f"Built {out_path} ({size:,} bytes)")
    print(f"Titles: {len(titles)} | Package choices: {total_releases} | Files: {len(payload_files)+1}")
    print("Engine: embedded-catalog-v1 | Entry: catalog.json")

if __name__ == "__main__":
    ap=argparse.ArgumentParser()
    ap.add_argument("input",type=Path,help="Input catalog JSON (see catalog/example.json)")
    ap.add_argument("output",type=Path,help="Output .gssource file")
    a=ap.parse_args(); build(a.input,a.output)
