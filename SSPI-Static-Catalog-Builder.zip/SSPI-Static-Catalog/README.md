# PS4 SSPI Static Catalog Builder

Builds `.gssource` ZIP packages for SSPI's `embedded-catalog-v1` engine. The generated source is declarative data only; it contains metadata and package URLs, not PKG payloads or account credentials.

## Important compatibility note

Use an SSPI build that supports `embedded-catalog-v1`. SSPI's source defines the engine type as `embedded-catalog-v1`, with `catalog.json` as the entry file. The public GitHub source is an overview and may omit build/runtime assets; this project uses the published validator's data contract.

## Build

Requires Python 3.10+; no third-party packages.

```bash
python tools/build_source.py catalog/example.json dist/my-library.gssource
```

The example uses the reserved `.invalid` domain and is deliberately non-downloadable. Replace it with a URL to a package you own or are authorized to distribute.

## Add your entries

Edit `catalog/example.json`:

- `source.id`: stable identifier, letters/digits/dot/underscore/hyphen.
- `source.name`: source label (up to 96 characters).
- `source.version`: numeric version with 2-4 components, e.g. `1.0` or `1.2.3`.
- `titleId`: PS4 title identifier, e.g. `CUSA12345` (PPSA/PS5 IDs are rejected by this engine).
- `region`: optional `US`, `EU`, `JP`, etc.
- `packages`: one or more package choices.
- `kind`: `base`, `update`, `dlc`, `unknown`, or `backport`.
- `accessType`: `Direct` or `HosterLanding`.
- `url`: direct file URL or host landing URL; HTTP(S) only, no embedded username/password.
- Optional metadata: `label`, `hoster`, `version`, `requiredFirmware`, `groupId`, `sourcePageUrl`, `size`, `sha256`, `contentId`.
- Multipart archives use `volumes`: 2-128 volumes in numeric order. The package's `url` and `accessType` must match the first volume.

Do not put Real-Debrid/TorBox/AllDebrid/Premiumize API keys, session cookies, signed account tokens or personal pairing tokens in this file.

## Format produced

```text
example.gssource (ZIP)
├── source.json
├── catalog.json
├── index/0001.json
└── packages/0001.json
```

`catalog.json` identifies `embedded-catalog-v1`, formatVersion 1, search normalization, index/package file lists and catalog counts. `source.json` includes schema `gamesearch.source/v1`, engine `embedded-catalog-v1`, entryFile `catalog.json`, capabilities and per-file SHA-256 plus byte size.

The builder groups all titles into one index file and all packages into one package shard. It is suitable for small and medium catalogs. Larger catalogs should be sharded to stay under the SSPI index/shard and memory limits; this version intentionally stops at the documented bounds rather than silently generating a catalog it cannot load.

## GitHub hosting

1. Build `dist/my-library.gssource`.
2. Push the source file and this builder to your GitHub repository.
3. Create a GitHub Release and attach the `.gssource` as a release asset.
4. Copy the direct asset URL:
   `https://github.com/OWNER/REPO/releases/download/TAG/my-library.gssource`
5. In SSPI, use Settings → Connections → Manage sources → Add a source link, or the phone page's Sources tab. The URL must point directly to the file.

A GitHub repository page URL is not a direct source URL.

## Validation

The builder validates fields, title IDs, URLs, package kinds, access types, multipart volume declarations, archive structure, and hashes. A successful local build is a structural check, not proof that a particular SSPI binary accepts the catalog or that every server link works. Test with a single authorized homebrew/test package first.

## References

- SSPI guide: https://xyhlo.github.io/SSPI/
- SSPI source: https://github.com/Xyhlo/SSPI
- Static catalog engine implementation: `app/PackageSourceEngineStatic.cs`
- Package archive/manifest validator: `app/PackageSourcePackage.cs`
